def scan_look_disk_scheduling():
    def scan(requests, head, direction, disk_size):
        seek_sequence = []
        seek_count = 0
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]

        left.sort()
        right.sort()

        if direction == "left":
            for track in reversed(left):
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
            seek_count += abs(head - 0)
            head = 0
            for track in right:
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
        else:
            for track in right:
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
            seek_count += abs(head - (disk_size - 1))
            head = disk_size - 1
            for track in reversed(left):
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track

        return seek_count, seek_sequence

    def look(requests, head, direction):
        seek_sequence = []
        seek_count = 0
        left = [r for r in requests if r < head]
        right = [r for r in requests if r >= head]

        left.sort()
        right.sort()

        if direction == "left":
            for track in reversed(left):
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
            for track in right:
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
        else:
            for track in right:
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track
            for track in reversed(left):
                seek_sequence.append(track)
                seek_count += abs(head - track)
                head = track

        return seek_count, seek_sequence

    # User Input Section
    n = int(input("Enter number of disk requests: "))
    requests = list(map(int, input("Enter disk requests (space-separated): ").split()))
    head = int(input("Enter initial head position: "))
    direction = input("Enter direction (left/right): ").lower()
    disk_size = int(input("Enter disk size (e.g., 200): "))

    print("\n--- SCAN Disk Scheduling ---")
    scan_seek, scan_seq = scan(requests, head, direction, disk_size)
    print("Seek Sequence:", scan_seq)
    print("Total Seek Operations (SCAN):", scan_seek)

    print("\n--- LOOK Disk Scheduling ---")
    look_seek, look_seq = look(requests, head, direction)
    print("Seek Sequence:", look_seq)
    print("Total Seek Operations (LOOK):", look_seek)
