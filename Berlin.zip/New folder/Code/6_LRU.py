def lru_user():
    pages = list(map(int, input("Enter page reference string (space-separated): ").split()))
    capacity = int(input("Enter number of frames: "))
    memory = []
    page_faults = 0
    recent = {}

    for i, page in enumerate(pages):
        if page not in memory:
            if len(memory) < capacity:
                memory.append(page)
            else:
                # Find the least recently used page
                lru_page = min(recent, key=recent.get)
                memory[memory.index(lru_page)] = page
                del recent[lru_page]
            page_faults += 1
        recent[page] = i  # Update most recent use
        print(f"Page: {page} -> Memory: {memory}")

    print(f"\nTotal Page Faults (LRU): {page_faults}")
