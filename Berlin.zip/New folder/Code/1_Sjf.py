# SJF Scheduling Algorithm with user input (Non-Preemptive)

n = int(input("Enter number of processes: "))
processes = []

for i in range(n):
    pid = i + 1
    bt = int(input(f"Enter burst time for Process P{pid}: "))
    processes.append({'pid': pid, 'bt': bt})

# Sort processes by burst time
processes.sort(key=lambda x: x['bt'])

waiting_time = 0
total_wt = 0
total_tat = 0

print("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time")
for p in processes:
    tat = waiting_time + p['bt']
    total_wt += waiting_time
    total_tat += tat
    print(f"P{p['pid']}\t{p['bt']}\t\t{waiting_time}\t\t{tat}")
    waiting_time += p['bt']

avg_wt = total_wt / n
avg_tat = total_tat / n

print(f"\nAverage Waiting Time: {avg_wt:.2f}")
print(f"Average Turnaround Time: {avg_tat:.2f}")
