def fifo_user():
    pages = list(map(int, input("Enter page reference string (space-separated): ").split()))
    capacity = int(input("Enter number of frames: "))
    memory = []
    page_faults = 0

    for page in pages:
        if page not in memory:
            if len(memory) < capacity:
                memory.append(page)
            else:
                memory.pop(0)
                memory.append(page)
            page_faults += 1
        print(f"Page: {page} -> Memory: {memory}")

    print(f"\nTotal Page Faults (FIFO): {page_faults}")
