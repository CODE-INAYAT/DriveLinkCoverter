# Round Robin Scheduling Algorithm with user input

def findWaitingTime(processes, n, bt, wt, quantum):
    rem_bt = bt[:]
    t = 0  # current time

    while True:
        done = True
        for i in range(n):
            if rem_bt[i] > 0:
                done = False
                if rem_bt[i] > quantum:
                    t += quantum
                    rem_bt[i] -= quantum
                else:
                    t += rem_bt[i]
                    wt[i] = t - bt[i]
                    rem_bt[i] = 0
        if done:
            break

def findTurnAroundTime(processes, n, bt, wt, tat):
    for i in range(n):
        tat[i] = bt[i] + wt[i]

def findAvgTime(processes, n, bt, quantum):
    wt = [0] * n
    tat = [0] * n

    findWaitingTime(processes, n, bt, wt, quantum)
    findTurnAroundTime(processes, n, bt, wt, tat)

    print("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time")
    total_wt = 0
    total_tat = 0
    for i in range(n):
        total_wt += wt[i]
        total_tat += tat[i]
        print(f"P{processes[i]}\t{bt[i]}\t\t{wt[i]}\t\t{tat[i]}")

    print(f"\nAverage Waiting Time = {total_wt / n:.2f}")
    print(f"Average Turnaround Time = {total_tat / n:.2f}")

# Get user input
n = int(input("Enter number of processes: "))
processes = []
burst_time = []

for i in range(n):
    processes.append(i + 1)
    bt = int(input(f"Enter burst time for Process P{i+1}: "))
    burst_time.append(bt)

quantum = int(input("Enter Time Quantum: "))

findAvgTime(processes, n, burst_time, quantum)
