def fcfs_sstf_disk_scheduling():
    def fcfs(requests, head):
        seek_sequence = []
        seek_count = 0

        for track in requests:
            seek_sequence.append(track)
            seek_count += abs(head - track)
            head = track

        return seek_count, seek_sequence

    def sstf(requests, head):
        seek_sequence = []
        seek_count = 0
        local_requests = requests[:]

        while local_requests:
            # Find the closest request
            distances = {track: abs(head - track) for track in local_requests}
            closest = min(distances, key=distances.get)

            seek_sequence.append(closest)
            seek_count += abs(head - closest)
            head = closest
            local_requests.remove(closest)

        return seek_count, seek_sequence

    # User Input Section
    n = int(input("Enter number of disk requests: "))
    requests = list(map(int, input("Enter disk requests (space-separated): ").split()))
    head = int(input("Enter initial head position: "))

    print("\n--- FCFS Disk Scheduling ---")
    fcfs_seek, fcfs_seq = fcfs(requests, head)
    print("Seek Sequence:", fcfs_seq)
    print("Total Seek Operations (FCFS):", fcfs_seek)

    print("\n--- SSTF Disk Scheduling ---")
    sstf_seek, sstf_seq = sstf(requests, head)
    print("Seek Sequence:", sstf_seq)
    print("Total Seek Operations (SSTF):", sstf_seek)
