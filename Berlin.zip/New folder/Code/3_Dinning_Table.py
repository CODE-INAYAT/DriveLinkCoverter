import threading
import time
import random

# Number of philosophers
n = 5

# Semaphores for forks
forks = [threading.Semaphore(1) for _ in range(n)]

# A waiter to avoid deadlock (at most n-1 philosophers can try to eat at once)
waiter = threading.Semaphore(n - 1)

def philosopher(i):
    left = i
    right = (i + 1) % n

    while True:
        print(f"Philosopher {i} is thinking.")
        time.sleep(random.uniform(1, 3))

        print(f"Philosopher {i} is hungry.")
        waiter.acquire()  # prevent deadlock
        forks[left].acquire()
        forks[right].acquire()

        print(f"Philosopher {i} is eating.")
        time.sleep(random.uniform(1, 2))

        forks[left].release()
        forks[right].release()
        waiter.release()

        print(f"Philosopher {i} finished eating.")

# Create and start threads
philosophers = []
for i in range(n):
    t = threading.Thread(target=philosopher, args=(i,))
    philosophers.append(t)
    t.start()

# Let the simulation run for a while
time.sleep(15)

# (Optional) In a real OS, you'd need a stop mechanism. This is just for demonstration.
print("Simulation ended.")


# import threading
# import time
# import random

# def dining_philosophers_user():
#     n = int(input("Enter number of philosophers: "))
#     forks = [threading.Semaphore(1) for _ in range(n)]
#     waiter = threading.Semaphore(n - 1)

#     def philosopher(i):
#         left = i
#         right = (i + 1) % n

#         while True:
#             print(f"Philosopher {i} is thinking.")
#             time.sleep(random.uniform(1, 2))

#             print(f"Philosopher {i} is hungry.")
#             waiter.acquire()
#             forks[left].acquire()
#             forks[right].acquire()

#             print(f"Philosopher {i} is eating.")
#             time.sleep(random.uniform(1, 2))

#             forks[left].release()
#             forks[right].release()
#             waiter.release()

#             print(f"Philosopher {i} finished eating.")

#     threads = []
#     for i in range(n):
#         t = threading.Thread(target=philosopher, args=(i,))
#         threads.append(t)
#         t.start()

#     time.sleep(15)
#     print("Simulation ended. (Press Ctrl+C to stop)")
