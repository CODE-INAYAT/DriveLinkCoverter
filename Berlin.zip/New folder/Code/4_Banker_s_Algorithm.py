def is_safe(processes, avail, max_demand, alloc):
    n = len(processes)
    m = len(avail)

    need = [[max_demand[i][j] - alloc[i][j] for j in range(m)] for i in range(n)]
    finish = [False] * n
    safe_seq = []
    work = avail[:]

    while len(safe_seq) < n:
        found = False
        for i in range(n):
            if not finish[i]:
                if all(need[i][j] <= work[j] for j in range(m)):
                    for j in range(m):
                        work[j] += alloc[i][j]
                    safe_seq.append(processes[i])
                    finish[i] = True
                    found = True
                    break
        if not found:
            return False, []

    return True, safe_seq

# Example input
processes = [0, 1, 2, 3, 4]
available = [3, 3, 2]

max_demand = [
    [7, 5, 3],
    [3, 2, 2],
    [9, 0, 2],
    [2, 2, 2],
    [4, 3, 3]
]

allocation = [
    [0, 1, 0],
    [2, 0, 0],
    [3, 0, 2],
    [2, 1, 1],
    [0, 0, 2]
]

safe, sequence = is_safe(processes, available, max_demand, allocation)

if safe:
    print("System is in a **SAFE STATE**.")
    print("Safe sequence:", ' -> '.join(f'P{p}' for p in sequence))
else:
    print("System is in an **UNSAFE STATE** (Deadlock possible).")


# def bankers_user():
#     n = int(input("Enter number of processes: "))
#     m = int(input("Enter number of resource types: "))

#     available = list(map(int, input("Enter available resources (space-separated): ").split()))
#     max_demand = []
#     allocation = []

#     print("Enter Max matrix:")
#     for i in range(n):
#         row = list(map(int, input(f"Max for P{i}: ").split()))
#         max_demand.append(row)

#     print("Enter Allocation matrix:")
#     for i in range(n):
#         row = list(map(int, input(f"Allocation for P{i}: ").split()))
#         allocation.append(row)

#     def is_safe(processes, avail, max_demand, alloc):
#         need = [[max_demand[i][j] - alloc[i][j] for j in range(m)] for i in range(n)]
#         finish = [False] * n
#         safe_seq = []
#         work = avail[:]

#         while len(safe_seq) < n:
#             found = False
#             for i in range(n):
#                 if not finish[i] and all(need[i][j] <= work[j] for j in range(m)):
#                     for j in range(m):
#                         work[j] += alloc[i][j]
#                     safe_seq.append(i)
#                     finish[i] = True
#                     found = True
#                     break
#             if not found:
#                 return False, []
#         return True, safe_seq

#     safe, sequence = is_safe(list(range(n)), available, max_demand, allocation)

#     if safe:
#         print("\nSystem is in a SAFE STATE.")
#         print("Safe sequence:", ' -> '.join(f'P{p}' for p in sequence))
#     else:
#         print("\nSystem is in an UNSAFE STATE (Deadlock possible).")
